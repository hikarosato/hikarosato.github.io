# Unity Catalog CRC_Patcher.py - (N o o B)
#
# Game: CarX Street, Outbound & others unity engine games
#
# Drag & drop Addressables catalog JSON or BIN file(s) onto this script (Windows),
# or run from the command line:
# CRC_Patcher.exe catalog.json\bin
#
# What it does:
#   - For JSON: Scans the m_ExtraDataString (base64 UTF-16LE), zeros out m_Crc.
#   - For BIN: Parses the binary offsets to find AssetBundleRequestOptions, zeros out the CRC.
#   - Creates a backup
#   - Overwrites the original file with the patched one keeping file length intact!


import sys
import os
import json
import base64
import struct

UTF16_CRC_PATTERN = b'"\x00m\x00_\x00C\x00r\x00c\x00"\x00:\x00'  # '"m_Crc":' in UTF-16LE


# ==========================================
# JSON HANDLING
# ==========================================

def patch_crc_in_extradata(extra_b64: str) -> tuple[str, int]:
    """
    Takes the m_ExtraDataString base64 string, decodes it,
    finds all `"m_Crc": <digits>` patterns encoded in UTF-16LE,
    replaces the digits with 0 (preserving length),
    and returns the new base64 string + number of modifications.
    """
    try:
        data = base64.b64decode(extra_b64, validate=True)
    except Exception as e:
        raise ValueError(f"Invalid base64 in m_ExtraDataString: {e}")

    b = bytearray(data)
    changes = 0
    i = 0
    pat = UTF16_CRC_PATTERN

    while True:
        idx = b.find(pat, i)
        if idx == -1:
            break

        # position after the colon
        j = idx + len(pat)

        # skip UTF-16LE spaces/tabs
        while j + 1 < len(b) and b[j] in b' \t' and b[j + 1] == 0x00:
            j += 2

        # collect digit run (UTF-16LE)
        start = j
        while j + 1 < len(b) and b[j] in b'0123456789' and b[j + 1] == 0x00:
            j += 2

        if j > start:
            # replace first digit with '0'
            b[start:start + 2] = b'0\x00'
            # fill remaining digits with spaces
            rest = j - (start + 2)
            for k in range(0, rest, 2):
                b[start + 2 + k:start + 2 + k + 2] = b' \x00'
            changes += 1

        i = j

    return base64.b64encode(b).decode("ascii"), changes

def patch_json_file(path: str) -> None:
    # Load JSON
    with open(path, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except Exception as e:
            print(f"[ERROR] Failed to parse JSON ({path}): {e}")
            return

    if "m_ExtraDataString" not in data or not isinstance(data["m_ExtraDataString"], str):
        print(f"[ERROR] Missing or invalid m_ExtraDataString in {path}")
        return

    # Patch CRCs
    try:
        new_extra, changes = patch_crc_in_extradata(data["m_ExtraDataString"])
    except Exception as e:
        print(f"[ERROR] CRC patch failed ({path}): {e}")
        return

    if changes == 0:
        print(f"[INFO] No m_Crc values found to patch (perhaps already zeroed): {path}")
    else:
        print(f"[OK] Patched {changes} m_Crc entries: {path}")

    data["m_ExtraDataString"] = new_extra

    # Create backup & save (Közös mentési rész)
    save_file(path, backup_data=None, save_func=lambda outf: json.dump(data, outf, ensure_ascii=False, separators=(",", ":")))


# ==========================================
# BINARY (.BIN) HANDLING
# ==========================================

def patch_bin_file(path: str) -> None:
    with open(path, "rb") as f:
        data = bytearray(f.read())
        
    if len(data) < 12:
        print(f"[ERROR] BIN File too small: {path}")
        return
        
    magic, version, keys_offset = struct.unpack_from('<III', data, 0)
    
    if magic not in (0x0de38942, 0x4289e30d):
        print(f"[ERROR] Invalid catalog magic number in {path}")
        return
    if magic == 0x4289e30d:
        print(f"[ERROR] Big endian catalogs are not supported: {path}")
        return
    if version not in (1, 2):
        print(f"[ERROR] Unsupported catalog version ({version}) in {path}")
        return
    if keys_offset < 4 or keys_offset > len(data):
        print(f"[ERROR] Invalid keys offset in {path}")
        return

    # Segédfüggvény egy offset tömb kiolvasására (C# ReadOffsetArray)
    def read_offset_array(offset):
        if offset == 0xFFFFFFFF or offset < 4 or offset > len(data):
            return[]
        byte_size = struct.unpack_from('<i', data, offset - 4)[0]
        if byte_size <= 0 or byte_size % 4 != 0 or offset + byte_size > len(data):
            return[]
        count = byte_size // 4
        return struct.unpack_from('<' + 'I' * count, data, offset)

    # Segédfüggvény stringek dekódolására (C# ReadEncodedString)
    def read_encoded_string(encoded_offset):
        if encoded_offset == 0xFFFFFFFF:
            return ""
        unicode = (encoded_offset & 0x80000000) != 0
        dynamic = (encoded_offset & 0x40000000) != 0
        offset = encoded_offset & 0x3FFFFFFF
        
        if not dynamic:
            if offset < 4 or offset > len(data): return ""
            byte_size = struct.unpack_from('<i', data, offset - 4)[0]
            if byte_size <= 0 or offset + byte_size > len(data): return ""
            str_bytes = data[offset : offset + byte_size]
            try:
                return str_bytes.decode('utf-16le') if unicode else str_bytes.decode('ascii')
            except Exception:
                return ""
        else:
            # Dynamic stringek esetén darabokból tevődik össze
            part_strs =[]
            curr_offset = offset
            while True:
                if curr_offset + 8 > len(data): break
                part_off, next_off = struct.unpack_from('<II', data, curr_offset)
                part_strs.append(read_encoded_string(part_off))
                if next_off == 0xFFFFFFFF: break
                curr_offset = next_off
            return "".join(part_strs)

    changes = 0
    visited_locs = set()
    visited_abro = set()

    # Végigmegyünk a gyökér ResourceLocation offseteken
    key_loc_offsets = read_offset_array(keys_offset)
    stack =[]
    for i in range(0, len(key_loc_offsets) - 1, 2):
        loc_list_offset = key_loc_offsets[i + 1]
        stack.extend(read_offset_array(loc_list_offset))

    # Mélységi bejárás az összes ResourceLocation felderítésére
    while stack:
        loc_offset = stack.pop()
        if loc_offset in visited_locs: continue
        if loc_offset + 28 > len(data): continue
        visited_locs.add(loc_offset)
        
        # Struct: PrimaryKey(4), InternalId(4), ProviderId(4), Dependencies(4), DepHash(4), Data(4), Type(4)
        pkOff, idOff, provOff, depOff, depHash, dataOff, typeOff = struct.unpack_from('<IIIIIII', data, loc_offset)
        
        if depOff != 0xFFFFFFFF:
            stack.extend(read_offset_array(depOff))
            
        # Ha tartalmaz Data-t
        if dataOff != 0xFFFFFFFF and dataOff + 8 <= len(data):
            # A C# SerializeObjectDecoder.DecodeV2 felépítése
            typeNameOffset, objectOffset = struct.unpack_from('<II', data, dataOff)
            
            if objectOffset != 0xFFFFFFFF and typeNameOffset + 8 <= len(data):
                asmNameOff, clsNameOff = struct.unpack_from('<II', data, typeNameOffset)
                class_name = read_encoded_string(clsNameOff)
                
                # Ha a Data egy AssetBundleRequestOptions
                if class_name and "AssetBundleRequestOptions" in class_name:
                    if objectOffset not in visited_abro:
                        visited_abro.add(objectOffset)
                        
                        # Az AssetBundleRequestOptions CRC adata pontosan a +8. bytetól kezdődik (4 byte)
                        if objectOffset + 12 <= len(data):
                            old_crc = struct.unpack_from('<I', data, objectOffset + 8)[0]
                            if old_crc != 0:
                                # Helyben átírjuk nullára!
                                struct.pack_into('<I', data, objectOffset + 8, 0)
                                changes += 1

    if changes == 0:
        print(f"[INFO] No m_Crc values found to patch (perhaps already zeroed): {path}")
    else:
        print(f"[OK] Patched {changes} AssetBundleRequestOptions CRC entries: {path}")

    # Mentés meghívása
    save_file(path, backup_data=data, save_func=lambda outf: outf.write(data))


# ==========================================
# FILE SAVING & ROUTER
# ==========================================

def save_file(path, backup_data, save_func):
    """Közös eljárás a backup készítésére és a mentésre"""
    folder = os.path.dirname(path)
    base = os.path.basename(path)
    name, ext = os.path.splitext(base)
    backup_name = f"{name}_backup{ext}"
    backup_path = os.path.join(folder, backup_name)

    # Elkerüljük a korábbi backup felülírását
    if os.path.exists(backup_path):
        i = 1
        while True:
            alt = os.path.join(folder, f"{name}_backup({i}){ext}")
            if not os.path.exists(alt):
                backup_path = alt
                break
            i += 1

    # Backup írása
    try:
        with open(backup_path, "wb") as bf:
            with open(path, "rb") as origf:
                bf.write(origf.read())
    except Exception as e:
        print(f"[ERROR] Failed to write backup ({backup_path}): {e}")
        return

    # Módosított verzió írása
    try:
        mode = "wb" if backup_data is not None else "w"
        encoding = None if backup_data is not None else "utf-8"
        with open(path, mode, encoding=encoding) as outf:
            save_func(outf)
    except Exception as e:
        print(f"[ERROR] Failed to write patched file ({path}): {e}")
        print(f"[INFO] The original backup is safe at: {backup_path}")
        return

    print(f"[DONE] Backup saved: {backup_path}")
    print(f"[DONE] Patched file overwritten: {path}")


def patch_file(path: str) -> None:
    if not os.path.isfile(path):
        print(f"[ERROR] File not found: {path}")
        return

    # Megpróbáljuk beazonosítani a fájl típusát az első néhány byte alapján
    try:
        with open(path, "rb") as f:
            head = f.read(4)
    except Exception as e:
        print(f"[ERROR] Could not read file {path}: {e}")
        return

    if len(head) < 4:
        print(f"[ERROR] File is too small: {path}")
        return

    try:
        magic = struct.unpack('<I', head)[0]
    except Exception:
        magic = 0

    is_binary = (magic in (0x0de38942, 0x4289e30d))
    is_json = False

    # Ha nem BIN, ellenőrizzük, hogy kezdődhet-e JSON kapcsos zárójellel
    if not is_binary:
        with open(path, "rb") as f:
            while True:
                c = f.read(1)
                if not c: break
                if c in b' \t\r\n': continue
                if c == b'{': is_json = True
                break

    # Feldolgozók hívása
    if is_binary:
        patch_bin_file(path)
    elif is_json:
        patch_json_file(path)
    else:
        # Ha a tartalom alapján nem egyértelmű, a kiterjesztésből próbáljuk kitalálni
        if path.lower().endswith(".json"):
            patch_json_file(path)
        elif path.lower().endswith(".bin"):
            patch_bin_file(path)
        else:
            print(f"[ERROR] Unknown file format (neither JSON nor recognized BIN): {path}")


def main():
    # ITT TÖRTÉNT A MÓDOSÍTÁS
    if len(sys.argv) < 2:
        print("""# Unity Catalog CRC Patcher - (N o o B)
#
# Game: CarX Street, Outbound & others unity engine games
#
# Drag & drop Addressables catalog JSON or BIN file(s) onto this script (Windows),
# or run from the command line:
# CRC_Patcher.exe catalog.json\\bin
#
# What it does:
#   - For JSON: Scans the m_ExtraDataString (base64 UTF-16LE), zeros out m_Crc.
#   - For BIN: Parses the binary offsets to find AssetBundleRequestOptions, zeros out the CRC.
#   - Creates a backup
#   - Overwrites the original file with the patched one keeping file length intact!""")
        input("\nNyomj Enter-t a kilépéshez...")
        return

    for p in sys.argv[1:]:
        try:
            patch_file(p)
        except KeyboardInterrupt:
            print("\n[INTERRUPTED]")
            break
        except Exception as e:
            print(f"[ERROR] Unexpected error ({p}): {e}")
            
    # Ez a sor gondoskodik arról, hogy drag & drop használat után se záródjon be egyből a CMD
    input("\nNyomj Enter-t a kilépéshez...")

if __name__ == "__main__":
    main()