import os
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import webbrowser

class RetocGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Retoc GUI - N o o B")
        self.root.geometry("850x850")
        self.root.minsize(750, 700)
        
        style = ttk.Style()
        if "vista" in style.theme_names():
            style.theme_use("vista")
        elif "winnative" in style.theme_names():
            style.theme_use("winnative")
            
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.retoc_exe = os.path.join(self.script_dir, "retoc.exe")
        
        self.setup_variables()
        self.create_widgets()
        self.on_tab_changed()

    def setup_variables(self):
        self.aes_key_var = tk.StringVar()
        self.header_version_var = tk.StringVar(value="None")
        self.asset_filter_var = tk.StringVar()
        self.extra_args_var = tk.StringVar()
        self.command_preview_var = tk.StringVar()
        
        # Engine Versions
        self.engine_versions = ["None", "UE4_26", "UE4_27"]
        for i in range(0, 31): self.engine_versions.append(f"UE5_{i}")
        for i in range(0, 31): self.engine_versions.append(f"UE6_{i}")
        self.ue_version_var = tk.StringVar(value="UE5_7")
            
        self.header_overrides =["None", "PreInitial", "Initial", "LocalizedPackages", 
                                 "OptionalSegmentPackages", "NoExportInfo", 
                                 "SoftPackageReferences", "SoftPackageReferencesOffset"]
                                 
        self.unpack_action_var = tk.StringVar(value="to-legacy") 
        self.unpack_input_var = tk.StringVar()
        self.unpack_output_var = tk.StringVar()

        self.pack_action_var = tk.StringVar(value="to-zen")
        self.pack_input_var = tk.StringVar()
        self.pack_output_var = tk.StringVar()
        
        self.util_action_var = tk.StringVar(value="info")
        self.util_input_var = tk.StringVar()

    def create_widgets(self):
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Global Settings Frame
        global_frame = ttk.LabelFrame(main_frame, text="Global Settings", padding=10)
        global_frame.pack(fill=tk.X, pady=(0, 10))

        # 1. Engine Version (REQUIRED)
        ttk.Label(global_frame, text="Engine Version (REQUIRED):", font=("Helvetica", 9, "bold")).grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Combobox(global_frame, textvariable=self.ue_version_var, values=self.engine_versions, state="readonly", width=15).grid(row=0, column=1, sticky=tk.W, padx=5, pady=5)
        self.ue_version_var.trace_add("write", self.update_command_preview)

        # 2. AES Key (Optional)
        ttk.Label(global_frame, text="AES Key (Optional):").grid(row=1, column=0, sticky=tk.W, pady=2)
        ttk.Entry(global_frame, textvariable=self.aes_key_var, width=60).grid(row=1, column=1, sticky=tk.W, padx=5, pady=2)
        self.aes_key_var.trace_add("write", self.update_command_preview)

        # 3. Header Override (Optional)
        ttk.Label(global_frame, text="Container Header Override (Optional):").grid(row=2, column=0, sticky=tk.W, pady=2)
        ttk.Combobox(global_frame, textvariable=self.header_version_var, values=self.header_overrides, state="readonly", width=30).grid(row=2, column=1, sticky=tk.W, padx=5, pady=2)
        self.header_version_var.trace_add("write", self.update_command_preview)
        
        # 4. Asset Filter (Optional)
        ttk.Label(global_frame, text="Asset File Name Filter (Optional):").grid(row=3, column=0, sticky=tk.W, pady=2)
        ttk.Entry(global_frame, textvariable=self.asset_filter_var, width=60).grid(row=3, column=1, sticky=tk.W, padx=5, pady=2)
        self.asset_filter_var.trace_add("write", self.update_command_preview)

        # Tabs
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

        self.tab_unpack = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_unpack, text="Unpack")
        self.setup_unpack_tab(self.tab_unpack)

        self.tab_pack = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_pack, text="Repack")
        self.setup_pack_tab(self.tab_pack)
        
        self.tab_utils = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.tab_utils, text="Utils")
        self.setup_utils_tab(self.tab_utils)

        self.tab_about = ttk.Frame(self.notebook, padding=20)
        self.notebook.add(self.tab_about, text="Credits")
        self.setup_about_tab(self.tab_about)

        # Bottom Area
        bottom_frame = ttk.Frame(main_frame)
        bottom_frame.pack(fill=tk.X)

        ttk.Label(bottom_frame, text="Additional CLI Options (Optional):").pack(anchor=tk.W)
        ttk.Entry(bottom_frame, textvariable=self.extra_args_var).pack(fill=tk.X, pady=(0, 10))
        self.extra_args_var.trace_add("write", self.update_command_preview)

        ttk.Label(bottom_frame, text="Command Preview:").pack(anchor=tk.W)
        ttk.Entry(bottom_frame, textvariable=self.command_preview_var, state="readonly").pack(fill=tk.X, pady=(0, 5))

        # Status and Progress
        status_frame = ttk.Frame(bottom_frame)
        status_frame.pack(fill=tk.X, pady=(5, 5))
        
        self.status_label = ttk.Label(status_frame, text="Status: IDLE", font=("Helvetica", 10, "bold"), foreground="gray")
        self.status_label.pack(side=tk.LEFT)
        
        self.batch_label = ttk.Label(status_frame, text="", font=("Helvetica", 9, "italic"), foreground="blue")
        self.batch_label.pack(side=tk.RIGHT)

        self.progress = ttk.Progressbar(bottom_frame, orient="horizontal", mode="determinate", value=0)
        self.progress.pack(fill=tk.X, pady=(0, 10))

        self.run_btn = ttk.Button(bottom_frame, text="▶ RUN COMMAND", command=self.run_command)
        self.run_btn.pack(pady=(0, 10), ipadx=20, ipady=5)

        ttk.Label(bottom_frame, text="Console Output:").pack(anchor=tk.W)
        self.console_text = tk.Text(bottom_frame, height=12, bg="black", fg="#00FF00", font=("Consolas", 10), relief=tk.SOLID, borderwidth=1)
        self.console_text.pack(fill=tk.BOTH, expand=True)
        self.console_text.configure(state=tk.DISABLED)

    def on_tab_changed(self, event=None):
        self.update_command_preview()
        idx = self.notebook.index(self.notebook.select())
        if idx == 0:
            self.run_btn.config(text="▶ RUN UNPACK")
        elif idx == 1:
            self.run_btn.config(text="▶ RUN REPACK")
        elif idx == 2:
            self.run_btn.config(text="▶ RUN UTILS")
        else:
            self.run_btn.config(text="▶ RUN COMMAND")

    def setup_unpack_tab(self, parent):
        ttk.Label(parent, text="Action:").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Combobox(parent, textvariable=self.unpack_action_var, values=["to-legacy", "unpack", "unpack-raw"], state="readonly", width=20).grid(row=0, column=1, sticky=tk.W, pady=5)
        self.unpack_action_var.trace_add("write", self.update_command_preview)

        ttk.Label(parent, text="Input Path (.utoc):").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(parent, textvariable=self.unpack_input_var, width=50).grid(row=1, column=1, pady=5, padx=5)
        
        # Folder Batch button REMOVED. Only Single File (Smart Mount) remains.
        ttk.Button(parent, text="Browse File", command=lambda: self.browse_path(self.unpack_input_var, False)).grid(row=1, column=2, padx=5)

        ttk.Label(parent, text="Output Directory:").grid(row=3, column=0, sticky=tk.W, pady=5)
        ttk.Entry(parent, textvariable=self.unpack_output_var, width=50).grid(row=3, column=1, pady=5, padx=5)
        ttk.Button(parent, text="Browse Dir", command=lambda: self.browse_path(self.unpack_output_var, True)).grid(row=3, column=2, columnspan=2, sticky=tk.EW, padx=5)

    def setup_pack_tab(self, parent):
        ttk.Label(parent, text="Action:").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Combobox(parent, textvariable=self.pack_action_var, values=["to-zen", "pack-raw"], state="readonly", width=20).grid(row=0, column=1, sticky=tk.W, pady=5)
        self.pack_action_var.trace_add("write", self.update_command_preview)

        ttk.Label(parent, text="Input Directory:").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(parent, textvariable=self.pack_input_var, width=50).grid(row=1, column=1, pady=5, padx=5)
        ttk.Button(parent, text="Browse Dir", command=self.browse_pack_input_dir).grid(row=1, column=2, columnspan=2, sticky=tk.EW, padx=5)

        ttk.Label(parent, text="Output Path (.utoc):").grid(row=2, column=0, sticky=tk.W, pady=5)
        ttk.Entry(parent, textvariable=self.pack_output_var, width=50).grid(row=2, column=1, pady=5, padx=5)
        ttk.Button(parent, text="Save As File", command=lambda: self.browse_save_file(self.pack_output_var, "UTOC File", ".utoc")).grid(row=2, column=2, padx=5)
        ttk.Button(parent, text="Browse Dir", command=lambda: self.browse_path(self.pack_output_var, True)).grid(row=2, column=3, padx=5)

    def setup_utils_tab(self, parent):
        ttk.Label(parent, text="Utility Action:").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Combobox(parent, textvariable=self.util_action_var, values=["info", "list", "verify", "manifest"], state="readonly", width=20).grid(row=0, column=1, sticky=tk.W, pady=5)
        self.util_action_var.trace_add("write", self.update_command_preview)

        ttk.Label(parent, text="Input .utoc File:").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(parent, textvariable=self.util_input_var, width=50).grid(row=1, column=1, pady=5, padx=5)
        ttk.Button(parent, text="Browse File", command=lambda: self.browse_path(self.util_input_var, False)).grid(row=1, column=2, padx=5)

    def setup_about_tab(self, parent):
        ttk.Label(parent, text="Original retoc CLI Tool", font=("Helvetica", 12, "bold")).pack(pady=(10, 5))
        ttk.Label(parent, text="Created by: trumank", font=("Helvetica", 10)).pack()
        
        link_frame = ttk.Frame(parent)
        link_frame.pack(pady=10)
        ttk.Label(link_frame, text="GitHub: ", font=("Helvetica", 10)).pack(side=tk.LEFT)
        link_label = tk.Label(link_frame, text="https://github.com/trumank/retoc", fg="blue", cursor="hand2", font=("Helvetica", 10, "underline"))
        link_label.pack(side=tk.LEFT)
        link_label.bind("<Button-1>", lambda e: webbrowser.open_new("https://github.com/trumank/retoc"))

        ttk.Separator(parent, orient='horizontal').pack(fill='x', pady=20, padx=50)

        ttk.Label(parent, text="GUI Wrapper", font=("Helvetica", 12, "bold")).pack(pady=(0, 5))
        ttk.Label(parent, text="Created by: N o o B", font=("Helvetica", 10)).pack()

    def browse_path(self, var, is_dir):
        if is_dir:
            path = filedialog.askdirectory(title="Select Directory")
        else:
            path = filedialog.askopenfilename(title="Select File", filetypes=[("UTOC Files", "*.utoc"), ("All Files", "*.*")])
        if path:
            var.set(path)
            self.update_command_preview()

    def browse_save_file(self, var, ext_title, ext):
        path = filedialog.asksaveasfilename(title="Save As", defaultextension=ext, filetypes=[(ext_title, f"*{ext}"), ("All files", "*.*")])
        if path:
            var.set(path)
            self.update_command_preview()

    def browse_pack_input_dir(self):
        path = filedialog.askdirectory(title="Select Input Directory")
        if path:
            self.pack_input_var.set(path)
            parent_dir = os.path.dirname(path)
            folder_name = os.path.basename(path)
            auto_output = os.path.join(parent_dir, f"{folder_name}.utoc").replace("\\", "/")
            self.pack_output_var.set(auto_output)
            self.update_command_preview()

    def get_command_parts(self, input_path, output_path, use_dir_mode=False):
        cmd = ["retoc.exe"]
        
        if self.aes_key_var.get().strip():
            cmd.extend(["--aes-key", self.aes_key_var.get().strip()])
        
        if self.header_version_var.get() != "None":
            cmd.extend(["--override-container-header-version", self.header_version_var.get()])

        current_tab_idx = self.notebook.index(self.notebook.select())
        current_action = ""
        
        if current_tab_idx == 0:
            current_action = self.unpack_action_var.get()
        elif current_tab_idx == 1:
            current_action = self.pack_action_var.get()
        elif current_tab_idx == 2:
            current_action = self.util_action_var.get()
        
        if current_action:
            cmd.append(current_action)

        # Version Flag
        ue_ver = self.ue_version_var.get().strip()
        if ue_ver and ue_ver != "None" and current_action in ["to-zen", "to-legacy"]:
            cmd.append(f"--version={ue_ver}")
            
        if self.asset_filter_var.get().strip():
            cmd.append(f'-f="{self.asset_filter_var.get().strip()}"')

        extra = self.extra_args_var.get().strip()
        if extra:
            cmd.extend(extra.split())

        # PATH LOGIC (Smart Mount)
        final_input = input_path
        
        # If Unpack tab, force Dir Mode (to simulate TUW behavior)
        if use_dir_mode and os.path.isfile(input_path):
            final_input = os.path.dirname(input_path)
            
        if final_input: cmd.append(f'"{final_input}"')
        if output_path: cmd.append(f'"{output_path}"')

        return cmd

    def build_command_preview(self):
        # Force dir mode for Unpack Tab
        use_dir_mode = True if self.notebook.index(self.notebook.select()) == 0 else False
        return " ".join(self.get_command_parts(self.unpack_input_var.get() or self.pack_input_var.get(), self.unpack_output_var.get() or self.pack_output_var.get(), use_dir_mode))

    def update_command_preview(self, *args):
        self.command_preview_var.set(self.build_command_preview())

    def log_to_console(self, text):
        self.console_text.configure(state=tk.NORMAL)
        self.console_text.insert(tk.END, text + "\n")
        self.console_text.see(tk.END) 
        self.console_text.configure(state=tk.DISABLED)

    def finish_processing(self):
        self.progress.stop()
        self.progress.config(value=0)
        self.run_btn.config(state=tk.NORMAL)
        self.status_label.config(text="Status: FINISHED", foreground="green")
        self.batch_label.config(text="")

    def run_process_thread(self):
        current_tab_idx = self.notebook.index(self.notebook.select())
        work_items = [] 

        if current_tab_idx == 0: # Unpack
            inp = self.unpack_input_var.get()
            out = self.unpack_output_var.get()
            
            # Simplified Logic: Always use Smart Mount Directory Extraction
            cmd_list = self.get_command_parts(inp, out, True) # True forces Dir Mode
            work_items.append((cmd_list, "Mount Directory Extraction"))

        elif current_tab_idx == 1: # Pack
            inp = self.pack_input_var.get()
            out = self.pack_output_var.get()
            cmd_list = self.get_command_parts(inp, out, False)
            work_items.append((cmd_list, "Repack"))

        elif current_tab_idx == 2: # Utils
            inp = self.util_input_var.get()
            cmd_list = self.get_command_parts(inp, None, False)
            work_items.append((cmd_list, "Utility"))

        # Execute
        total_items = len(work_items)
        for i, (cmd, desc) in enumerate(work_items):
            cmd_string = " ".join(cmd)
            
            self.root.after(0, lambda d=desc, c=i+1, t=total_items: self.update_status(d, c, t))
            self.root.after(0, lambda msg=f"--- RUNNING: {desc} ---\n> {cmd_string}\n": self.log_to_console(msg))

            try:
                process = subprocess.Popen(
                    cmd_string, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.STDOUT, 
                    text=True, 
                    encoding="utf-8", 
                    errors="replace",
                    shell=True,
                    cwd=self.script_dir
                )

                for line in process.stdout:
                    self.root.after(0, self.log_to_console, line.strip())

                process.wait()
                
                if process.returncode != 0:
                     self.root.after(0, lambda c=process.returncode: self.log_to_console(f"FAILED with code {c}"))
                else:
                     self.root.after(0, lambda: self.log_to_console("SUCCESS"))

            except Exception as e:
                self.root.after(0, lambda err=str(e): self.log_to_console(f"CRITICAL ERROR: {err}"))

        self.root.after(0, self.finish_processing)

    def update_status(self, desc, current, total):
        self.status_label.config(text="Status: PROCESSING...", foreground="blue")
        if total > 1:
            self.batch_label.config(text=f"Batch Progress: {current}/{total}")
            step = (current / total) * 100
            self.progress.config(mode="determinate", value=step)
        else:
            self.batch_label.config(text="")
            self.progress.config(mode="indeterminate")
            self.progress.start(10)

    def run_command(self):
        current_tab_idx = self.notebook.index(self.notebook.select())
        if current_tab_idx == 3: 
            messagebox.showinfo("Info", "Select a function tab first.")
            return

        if not os.path.exists(self.retoc_exe):
            messagebox.showerror("Error", f"retoc.exe missing at:\n{self.retoc_exe}")
            return

        self.console_text.configure(state=tk.NORMAL)
        self.console_text.delete(1.0, tk.END)
        self.console_text.configure(state=tk.DISABLED)
        self.run_btn.config(state=tk.DISABLED)
        
        thread = threading.Thread(target=self.run_process_thread, daemon=True)
        thread.start()

if __name__ == "__main__":
    root = tk.Tk()
    app = RetocGUI(root)
    root.mainloop()